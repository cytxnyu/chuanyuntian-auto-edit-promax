import { Menu } from "lucide-react";
import Link from "next/link";
import { Button, buttonVariants } from "@/components/ui/button";
import {
  Sheet,
  SheetClose,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { NAV_LINKS } from "@/config/site";
import { cn } from "@/lib/utils";
import { GithubButton } from "./github-button";
import { NavMobile } from "./header-nav";
import { StarsButton } from "./stars-button";
import { ThemeToggle } from "./theme-toggle";

export function HeaderLogo() {
  return (
    <Link
      href="/"
      aria-label="remocn"
      className="flex items-baseline text-lg font-semibold tracking-tight text-foreground focus-visible:outline-none"
    >
      <svg
        viewBox="0 0 124.06 134.26"
        aria-hidden="true"
        className="h-[0.76em] w-auto"
      >
        <path
          fill="currentColor"
          d="M 0.01 0.81 C 0.01 1.73, 0.36 2.79, 1.09 4.13 C 4.91 11.04, 13.45 17.16, 21.7 18.9 C 22.94 19.16, 23.18 19.16, 51.39 19.27 C 76.07 19.36, 80.02 19.4, 81.32 19.57 C 89.89 20.69, 96.2 24.68, 99.38 31.01 C 103.19 38.56, 102.53 50.1, 97.91 57.07 C 94.66 61.96, 89.68 64.99, 83.26 66 C 82.81 66.07, 70.18 66.83, 55.2 67.69 C 24.82 69.43, 27.03 69.23, 24.18 70.4 C 19.9 72.15, 14.84 75.7, 10.65 79.89 C 4.86 85.68, 1.3 91.91, 0.25 98.13 C 0.12 98.85, 0.08 103.13, 0.04 116.66 L 0 134.26 9.5 134.26 L 19 134.26 19.05 119.41 C 19.1 103.27, 19.08 103.82, 19.82 101.04 C 21.79 93.65, 27.86 88.75, 36.45 87.63 C 37.23 87.53, 39.41 87.5, 43.57 87.53 C 50.12 87.59, 50.75 87.65, 53.22 88.45 C 56.61 89.56, 59.67 91.86, 62.02 95.07 C 62.52 95.76, 69.35 103.85, 77.2 113.07 C 85.04 122.28, 91.63 130.04, 91.85 130.32 C 92.07 130.59, 92.5 131.34, 92.82 131.97 C 93.52 133.35, 94.11 133.93, 95.06 134.13 C 95.5 134.23, 98.97 134.26, 106.36 134.23 L 117.01 134.19 100.82 113.07 C 91.91 101.45, 84.52 91.78, 84.39 91.57 C 83.36 89.89, 83.66 87.53, 85.09 86 C 85.79 85.25, 86.36 84.94, 88.07 84.38 C 96.18 81.72, 104.15 76.62, 109.97 70.36 C 120.59 58.93, 124.06 44.32, 119.44 30.43 C 114.59 15.81, 101.93 4.02, 87.64 0.83 C 83.93 0.01, 88.09 0.08, 41.85 0.04 L 0.01 0 0.01 0.81 Z"
        />
      </svg>
      <span className="ml-[0.04em]">emocn</span>
    </Link>
  );
}

export function HeaderActions({ cta = false }: { cta?: boolean }) {
  return (
    <div className="flex items-center gap-2">
      <div className="hidden sm:block">
        <GithubButton />
      </div>
      <ThemeToggle />
      {cta && (
        <Link
          href="/docs/getting-started/introduction"
          data-track="cta_clicked"
          data-cta="get_started_header"
          data-destination="/docs/getting-started/introduction"
          className={cn(
            buttonVariants({ size: "sm" }),
            "hidden h-9 rounded-full px-4 sm:inline-flex",
          )}
        >
          Get started
        </Link>
      )}

      <Sheet>
        <SheetTrigger
          render={
            <Button
              variant="outline"
              size="icon"
              className="rounded-full sm:hidden"
              aria-label="Open menu"
            />
          }
        >
          <Menu className="size-4" aria-hidden="true" />
        </SheetTrigger>
        <SheetContent side="right" className="bg-background">
          <SheetHeader>
            <SheetTitle>Menu</SheetTitle>
          </SheetHeader>
          <NavMobile links={NAV_LINKS} />
          <div className="mt-4 flex flex-col gap-4 px-6 pb-6">
            <SheetClose
              render={<StarsButton className="w-full justify-center" />}
            />
            <GithubButton />
            <SheetClose
              render={
                <Link
                  href="/docs/getting-started/introduction"
                  aria-label="Get started"
                  className={cn(
                    buttonVariants({ size: "lg" }),
                    "h-11 w-full rounded-full",
                  )}
                />
              }
            >
              Get started
            </SheetClose>
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
}
